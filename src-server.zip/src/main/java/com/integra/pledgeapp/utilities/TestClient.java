package com.integra.pledgeapp.utilities;

import java.util.Random;

import com.integra.pledgeapp.beans.Employee_Master;
import com.integra.pledgeapp.core.PledgeAppDAOImpl;
import com.integra.pledgeapp.core.PledgeAppDAOServices;

public class TestClient {
	
//public static void main(String[] args) {
		
//		MySignClient.fileDownload();
//		MySignClient.sendFile();
//		MySignClient.validateLogin();
//		Employee_Master es=new Employee_Master();
//		es.setEMP_COMPANY("i25RMCS");
//		es.setEMP_NAME("Naga Veera Venkata Satyanarayana Adimulam");
//		es.setEMP_ID("3092");
//		es.setEMP_COMPANY("IMFAST");
//		es.setEMP_NAME("Debashish Rout");
//		es.setEMP_ID("3090");
//	
//		GeneratePDF.generatePDF(es,"23123");
	
//		PledgeAppDAOServices PL=new PledgeAppDAOImpl();
//		PL.updateEmployeeSignStatus("abcbdbfsfsf/wee", "d6896522-dd51-4b91-857b-c795e3eb0cbf");
//	TestClient TC=new TestClient();
//	TC.test();
//	}
//public  void test()
//{
//	System.out.println("["+this.getClass().getName()+"]["+this.getClass().getEnclosingMethod().getName()+"] Exception :");

//	Random rr = new Random(System.currentTimeMillis());
//	String otp = 100000 + rr.nextInt(900000) +"";
//	System.out.println(otp);
//}
}
